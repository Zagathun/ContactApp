package com.example.taskmanagmentapp.Data.Service

import com.example.taskmanagmentapp.Data.ModelResponse.TaskModel
import com.example.taskmanagmentapp.Data.Network.TaskApiClient
import com.example.taskmanagmentapp.Data.Provider.TaskProvider
import com.example.taskmanagmentapp.Data.TaskDatabase.TaskEntity
import com.example.taskmanagmentapp.TaskManagmentApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class TaskService {

    private val taskProvider = TaskProvider()

    suspend fun getTasks(): List<TaskEntity> {

        var tasksFromDatabase = getTasksFromDatabase()

        println("TaskService / getTasks")

        if (tasksFromDatabase.isEmpty()) {
            val tasksFromApi = getTasksFromApi()
            println("Que trae getTasksFromApi")
            println(tasksFromApi)

            saveAllTasksOnDatabase(tasksFromApi)
            tasksFromDatabase = getTasksFromDatabase()
        }
        return withContext(Dispatchers.IO) {
            tasksFromDatabase
        }
    }

    suspend fun saveTask(task: TaskEntity) {
        TaskManagmentApp.database.taskDao().saveTask(task)

    }

    suspend fun saveAllTasksOnDatabase(task: List<TaskModel>) {

        val tasks = getTasksFromApi()

        tasks.forEach { task ->
            val newTask = TaskEntity(
                id = task.id,
                title = task.title,
                content = task.content,
                creationDate = task.creationDate,
                dueDate = task.dueDate,
                image = task.image,
                completed = task.isDone
            )

            saveTask(newTask)

        }
    }

    suspend fun getTasksFromDatabase(): List<TaskEntity> {
        val task = TaskManagmentApp.database.taskDao().getAllTask()
        println("DataService/ GetDataFromDatabase")
        println(this)
        return task
    }

    suspend fun getTasksFromApi(): List<TaskModel> {
        val response = taskProvider.providerRetrofit().create(TaskApiClient::class.java).getTask()
        println("DataService/ GetTaskFromApi")
        println(response)

        if (response.isSuccessful) {
            println("Solicitud exitosa : ${response.body()}")
            return response.body()?.data ?: emptyList()

        } else {
            println("Solicitud fallida: info del error ${response.code()}")
            return emptyList()
        }
    }

    suspend fun updateTask(task: TaskEntity) {
        return TaskManagmentApp.database.taskDao().updateTask(task)
    }

    suspend fun deleteAllTasks() {
        return TaskManagmentApp.database.taskDao().deleteAllTasks()
    }


}


