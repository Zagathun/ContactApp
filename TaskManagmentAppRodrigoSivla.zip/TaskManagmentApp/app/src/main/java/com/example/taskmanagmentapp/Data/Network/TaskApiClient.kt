package com.example.taskmanagmentapp.Data.Network

import com.example.taskmanagmentapp.Data.ModelResponse.TaskResponse
import retrofit2.Response
import retrofit2.http.GET

interface TaskApiClient {
    @GET("/")
suspend fun getTask(): Response<TaskResponse>
}