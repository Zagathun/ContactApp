package com.example.taskmanagmentapp

import android.app.Application
import com.example.taskmanagmentapp.Data.Provider.TaskProvider
import com.example.taskmanagmentapp.Data.TaskDatabase.TaskDatabase


class TaskManagmentApp : Application() {

    private val taskProvider = TaskProvider()

    companion object {
        lateinit var database: TaskDatabase
    }

    override fun onCreate() {
        super.onCreate()
        database = taskProvider.providerRoom(this)
    }

}