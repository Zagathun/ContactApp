package com.example.taskmanagmentapp.View.TaskList

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.taskmanagmentapp.Data.ModelResponse.TaskModel
import com.example.taskmanagmentapp.R
import com.example.taskmanagmentapp.View.Adapter.TaskAdapter
import com.example.taskmanagmentapp.View.TaskDetail.TaskDetailFragment
import com.example.taskmanagmentapp.ViewModel.TaskViewModel
import com.example.taskmanagmentapp.databinding.FragmentTaskDetailBinding
import com.example.taskmanagmentapp.databinding.FragmentTaskListBinding
import kotlinx.coroutines.launch
import java.security.acl.Owner


class TaskListFragment : Fragment() {

    private lateinit var binding: FragmentTaskListBinding
    private lateinit var taskAdapter: TaskAdapter
    private val taskViewModel: TaskViewModel by activityViewModels()
    private lateinit var recyclerView: RecyclerView
    private val taskDetailFragment = TaskDetailFragment()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {

        binding = FragmentTaskListBinding.inflate(layoutInflater)



        initRecyclerView()
        observeViewModel()
        initUiListener()
        return binding.root
    }

    private fun initUiListener() {

        taskViewModel.tasks.observe(viewLifecycleOwner, Observer { tasks ->
            println("contacts from ContactsListFragment")
            println(tasks)

            binding.RecyclerView.layoutManager = LinearLayoutManager(context)
            binding.RecyclerView.adapter = TaskAdapter(tasks) { task ->
                println(task)
                taskViewModel.setCurrentTask(task)



            }
        })
    }


    private fun initRecyclerView() {

        taskAdapter = TaskAdapter(emptyList()) { task ->
            taskViewModel.setCurrentTask(task)

        }


        recyclerView = binding.RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = taskAdapter
    }

    private fun observeViewModel() {
        taskViewModel.tasks.observe(viewLifecycleOwner) { tasks ->
            taskAdapter.updateTasks(tasks)
        }
    }

}