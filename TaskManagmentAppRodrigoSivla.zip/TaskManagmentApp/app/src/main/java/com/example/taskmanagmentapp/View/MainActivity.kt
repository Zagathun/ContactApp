package com.example.taskmanagmentapp.View

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.example.taskmanagmentapp.Data.TaskDatabase.TaskEntity
import com.example.taskmanagmentapp.R
import com.example.taskmanagmentapp.View.NewTask.NewTaskFragment
import com.example.taskmanagmentapp.View.TaskDetail.TaskDetailFragment
import com.example.taskmanagmentapp.View.TaskList.TaskListFragment
import com.example.taskmanagmentapp.ViewModel.TaskViewModel
import com.example.taskmanagmentapp.databinding.ActivityMainBinding
import com.example.taskmanagmentapp.databinding.FragmentTaskListBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val newTaskFragment = NewTaskFragment()
    private val taskDetailFragment = TaskDetailFragment()
    private val taskListFragment = TaskListFragment()

    private val taskViewModel: TaskViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initialUi()
    }

    private fun initialUi() {
        initialUiState()
        initialUiListener()
    }

    private fun initialUiState() {
        taskViewModel.getTask()
        startTaskListFragment()
    }

    private fun initialUiListener() {
        binding.ButonAdd.isVisible = true
        binding.ButonBack.isVisible = false
        binding.Title.isVisible = true


        //Esta parte envia al detail del contacto
        taskViewModel.currentTask.observe(this, Observer { currentTask ->
            if (currentTask != null) {
                startDetailTaskFragment(currentTask)
                println("detail")
                println(currentTask)
                binding.ButonAdd.isVisible = false
                binding.ButonBack.isVisible = true
                binding.Title.isVisible = true
            }
        })

        //Esta parte es la funcion del boton back
        binding.ButonBack.setOnClickListener{
            supportFragmentManager.beginTransaction().apply {
                replace(binding.frameLayoutFragment.id, taskListFragment)
                commit()
                taskViewModel.getTask()

                binding.Title.text = "Task Managment App"
                binding.ButonAdd.isVisible = true
                binding.ButonBack.isVisible = false
            }
        }

        binding.ButonAdd.setOnClickListener{
            taskViewModel.deleteAllData()
        }



    }

    private fun setCurrentFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().apply {
            replace(binding.frameLayoutFragment.id, fragment)
            commit()
        }
    }

    private fun startTaskListFragment() {
        setCurrentFragment(taskListFragment)
        taskViewModel.resultTaskList()
    }

    private fun startDetailTaskFragment(currentTask: TaskEntity) {
        setCurrentFragment(taskDetailFragment)
        binding.Title.text = currentTask.title
    }
}