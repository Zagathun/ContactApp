package com.example.taskmanagmentapp.ViewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.taskmanagmentapp.Data.Service.TaskService
import com.example.taskmanagmentapp.Data.TaskDatabase.TaskEntity

import kotlinx.coroutines.launch

class TaskViewModel : ViewModel() {

    val currentTask = MutableLiveData<TaskEntity?>(null)
    val tasks = MutableLiveData<List<TaskEntity>>()
    var taskListFromDatabase: List<TaskEntity> = emptyList()
    private val taskService = TaskService()

    fun getTask() {
        viewModelScope.launch {
            val result = taskService.getTasks()
            taskListFromDatabase = result

            println("ViewModel / TaskViewModel")
            println(result)

            if (result.isNotEmpty()) {
                tasks.postValue(result)
            }
        }
    }

    fun setCurrentTask(taskCurrent: TaskEntity) {
        currentTask.postValue(taskCurrent)
    }


    fun resultTaskList() {
        tasks.postValue(taskListFromDatabase)
    }



    fun updateTask(completed: Boolean) {
        viewModelScope.launch {
            // Encuentra la tarea actual
            val currentTaskValue = currentTask.value

            if (currentTaskValue != null) {

                val taskUpdate = currentTaskValue.copy(completed = completed)


                taskService.updateTask(taskUpdate)


                currentTask.postValue(taskUpdate)


                taskListFromDatabase = taskListFromDatabase.map {
                    if (it.id == taskUpdate.id) taskUpdate else it
                }
                tasks.postValue(taskListFromDatabase)
            }
        }
    }

    fun deleteAllData() {
        viewModelScope.launch{
            taskService.deleteAllTasks()
            val result = taskService.getTasks()
            tasks.postValue(result)
        }
    }
}