package com.example.taskmanagmentapp.Data.Provider

import android.content.Context
import androidx.room.Room
import com.example.taskmanagmentapp.Data.TaskDatabase.TaskDatabase
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class TaskProvider {

    fun providerRetrofit(): Retrofit {
        val endpointUrl = "https://curso-android-55-1.vercel.app/"
        return Retrofit.Builder()
            .baseUrl(endpointUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    fun providerRoom(context: Context): TaskDatabase {
        return Room.databaseBuilder(context, TaskDatabase::class.java, "task-db")
            .fallbackToDestructiveMigrationFrom()
            .allowMainThreadQueries()
            .build()
    }

}


