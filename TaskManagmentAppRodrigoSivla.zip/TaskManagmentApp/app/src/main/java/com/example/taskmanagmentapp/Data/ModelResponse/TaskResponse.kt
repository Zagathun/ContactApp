package com.example.taskmanagmentapp.Data.ModelResponse

import com.google.gson.annotations.SerializedName

class TaskResponse (
    val data: List<TaskModel>,)


data class TaskModel(
    val id: String,
    val title: String,
    val content: String,
    @SerializedName("creation_date")
    val creationDate: String,  // Cambiar a String
    @SerializedName ("due_date")
    val dueDate: String,  // Cambiar a String
    val image: String,
    val isDone: Boolean,
)