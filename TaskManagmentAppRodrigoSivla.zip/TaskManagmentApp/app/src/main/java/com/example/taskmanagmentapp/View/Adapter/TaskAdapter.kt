package com.example.taskmanagmentapp.View.Adapter

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.taskmanagmentapp.Data.ModelResponse.TaskModel
import com.example.taskmanagmentapp.Data.TaskDatabase.TaskEntity
import com.example.taskmanagmentapp.R
import com.example.taskmanagmentapp.databinding.FragmentNewTaskBinding
import com.example.taskmanagmentapp.databinding.ItemTaskListBinding
import com.squareup.picasso.Picasso


class TaskAdapter(
    private var tasks: List<TaskEntity>,
    private val onItemClick: (TaskEntity) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {



    inner class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val taskTitle: TextView = itemView.findViewById(R.id.taskTitle)
        private val taskContent: TextView = itemView.findViewById(R.id.taskDescription)
        private val taskImage: ImageView = itemView.findViewById(R.id.img_Data)
        private val taskIsDone: CheckBox = itemView.findViewById(R.id.checkbox)

        fun bind(task: TaskEntity) {
            taskTitle.text = task.title
            taskContent.text = task.content
            taskIsDone.isChecked = task.completed
            if (task.completed) {
                taskTitle.paintFlags = taskTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                taskContent.paintFlags = taskContent.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            } else {
                taskTitle.paintFlags = taskTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                taskContent.paintFlags = taskContent.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            }
            itemView.setOnClickListener{
                onItemClick(task)
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task_list, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(tasks[position])
    }

    override fun getItemCount(): Int = tasks.size

fun updateTasks(newTasks: List<TaskEntity>) {
    this.tasks = newTasks
    notifyDataSetChanged()
}


}