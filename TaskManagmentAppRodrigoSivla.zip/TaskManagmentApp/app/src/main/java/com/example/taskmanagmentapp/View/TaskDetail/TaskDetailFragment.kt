package com.example.taskmanagmentapp.View.TaskDetail

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.example.taskmanagmentapp.R
import com.example.taskmanagmentapp.View.Adapter.TaskAdapter
import com.example.taskmanagmentapp.ViewModel.TaskViewModel
import com.example.taskmanagmentapp.databinding.FragmentNewTaskBinding
import com.example.taskmanagmentapp.databinding.FragmentTaskDetailBinding
import com.squareup.picasso.Picasso


class TaskDetailFragment : Fragment() {

    private lateinit var binding: FragmentTaskDetailBinding
    private val taskViewModel: TaskViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
  
        binding = FragmentTaskDetailBinding.inflate(inflater, container, false)

        initUi()
        return binding.root
    }

    private fun initUi() {
        println("TaskDetail / InitUi")
        initUiState()
        initUiListener()  
    }

    private fun initUiState() {
        taskViewModel.currentTask.observe(viewLifecycleOwner, Observer { currentTask ->
            if (currentTask != null) {
                println(currentTask.content)
                binding.content.text = currentTask.content
                //Picasso.get().load(currentTask.image).into(binding.imgData)
            }
        })
    }

    private fun initUiListener() {
        binding.botonComplete.setOnClickListener {
            taskViewModel.updateTask(completed = true)
        }
    }
}





